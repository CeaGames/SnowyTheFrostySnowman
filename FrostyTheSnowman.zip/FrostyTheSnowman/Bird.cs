﻿using Microsoft.Xna.Framework;
using System;

namespace FrostyTheSnowman
{
    internal class Bird : GameObject
    {
        private float initialX;
        private float elapsedTime;
        private bool isVelocityReset;

        public Bird(SpriteSheet visualization, Vector2 position, Vector2 size, Vector2 velocity)
            : base(visualization, position, size, velocity)
        {
            this.initialX = position.X;
            this.elapsedTime = 0f;
            this.isVelocityReset = false;
        }

        public override void Update(GameTime gameTime)
        {
            elapsedTime += (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Reset velocity every five seconds
            if (elapsedTime >= 0.5f && elapsedTime <= 0.6f)
            {
                Velocity = new Vector2(Level.levelSpeed/2, 0); ;
                
            }
            if (elapsedTime >= 1)
            {
                Velocity = new Vector2(-Level.levelSpeed*2, 0);
                elapsedTime = 0f;
                
            }

            // Global leftward movement with the platforms
            TopLeftPosition += Velocity;
        }
    }
}
