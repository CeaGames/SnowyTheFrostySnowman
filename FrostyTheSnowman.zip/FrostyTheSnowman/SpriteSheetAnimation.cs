﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class SpriteSheetAnimation : SpriteSheet
{
    // Properties
    public int MinSpriteIndex { get; set; }
    public int MaxSpriteIndex { get; set; }
    public int IdleSpriteIndex { get; set; }
    public int AnimationDelayInFrames { get; set; }
    public bool IsAnimationStopped { get; set; }

    // Constructor
    public SpriteSheetAnimation(Texture2D texture, int rows, int columns)
        : base(texture, rows, columns)
    {
        // Initialize other properties as needed
    }

    // Methods
    public override void Update(GameTime gameTime)
    {
        // Add animation logic
    }

    public override void Draw(SpriteBatch spriteBatch, Vector2 position, Vector2 size)
    {
        base.Draw(spriteBatch, position, size);
    }
}
