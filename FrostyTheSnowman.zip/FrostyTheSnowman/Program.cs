﻿
using var game = new FrostyTheSnowman.Game1();
game.Run();
