﻿public class Button : TextControl
{
    // No additional functionality
}
