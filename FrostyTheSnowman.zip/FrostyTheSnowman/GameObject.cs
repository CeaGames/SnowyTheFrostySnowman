﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

public abstract class GameObject
{
    // Properties
    public SpriteSheet Visualization { get; set; }
    public Vector2 TopLeftPosition { get; set; }
    public Vector2 Size { get; set; }
    public bool IsActive { get; set; }
    public Vector2 Velocity { get; set; }
    public float InitialRotation { get; set; }
    public bool IsOffScreen
    {
        get
        {
            return TopLeftPosition.X + Size.X < 0;
        }
    }

    // Constructor
    public GameObject(SpriteSheet visualization, Vector2 position, Vector2 size, Vector2 velocity)
    {
        Visualization = visualization;
        TopLeftPosition = position;
        Size = size;
        Velocity = velocity;
        IsActive = true;
    }

    // Methods
    public virtual void Update(GameTime gameTime)
    {
        if (!IsActive)
            return;

        MoveGameObject(gameTime);

        Visualization.Update(gameTime);
    }

    public virtual void MoveGameObject(GameTime gameTime)
    {
        TopLeftPosition += Velocity;
    }

    public virtual void Draw(SpriteBatch spriteBatch)
    {
        if (!IsActive)
            return;

        Visualization.Draw(spriteBatch, TopLeftPosition, Size);
    }

    public bool IsCollidingWith(GameObject other)
    {
        return this.GetHitBoxRectangle().Intersects(other.GetHitBoxRectangle());
    }

    public Rectangle GetHitBoxRectangle()
    {
        return new Rectangle(TopLeftPosition.ToPoint(), Size.ToPoint());
    }
}
