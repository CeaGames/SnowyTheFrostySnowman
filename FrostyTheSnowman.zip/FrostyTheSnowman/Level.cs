﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;

namespace FrostyTheSnowman
{
    internal static class Level // Composing all objects/classes we need for the Level
    {
        // Level settings
        public static float levelSpeed = 6f;

        private static int gridRows = 10;
        private static int gridCols = 16;
        private static int cellWidth = GameSettings.ScreenWidth / gridCols;
        private static int cellHeight = GameSettings.ScreenHeight / gridRows;

        // Platform stuff
        public static List<Platform> platforms = new List<Platform>();

        public static List<Platform> floorPlatforms = new List<Platform>();
        public static List<Platform> roofPlatforms = new List<Platform>();
        public static List<Platform> obstaclePlatforms = new List<Platform>();

        public static List<Platform> ballPlatforms = new List<Platform>();

        private static Texture2D platformTexture;
        private static SpriteSheet platformSheet;

        // Bird Stuff
        public static List<Bird> birds = new List<Bird>();

        private static SpriteSheet birdSheet;

        // Lava Stuff
        public static List<Lava> lavaBlocks = new List<Lava>();

        // RandomGenStuff
        private static Random random = new Random();

        private static bool hasGeneratedFloorPlatforms = false;
        private static bool hasGeneratedObstaclePlatforms = false;
        private static bool hasGeneratedRoofPlatforms = false;
        
        private static bool hasGeneratedBirds = false;

        private static bool hasGeneratedLava = false;

        private static List<Vector2> floorEmptyPoints = new List<Vector2>();
        private static List<Vector2> obstacleEmptyPoints = new List<Vector2>();
        private static List<Vector2> roofEmptyPoints = new List<Vector2>();

        private static List<Vector2> birdEmptyPoints = new List<Vector2>();

        private static List<Vector2> lavaEmptyPoints = new List<Vector2>();


        public static void LoadContent()
        {
            //Loading textures
            platformTexture = GameSettings.Textures[2];
            platformSheet = new SpriteSheet(platformTexture, 1, 1);
            
            birdSheet = new SpriteSheet(GameSettings.Textures[3], 3, 5); ;


            // Initial platform logistics
            Vector2 position = new Vector2(0 * cellWidth, (gridRows-1) * cellHeight);
            Vector2 size = new Vector2(cellWidth, cellHeight);

            // Set initial velocity for the platform
            Vector2 velocity = new Vector2(-levelSpeed, 0);

            // Generate initial platforms
            for (int i = 1; i <= gridRows; i++) //generate howManyPlatformsPerSpawn platforms
            {
                platforms.Add(new Platform(platformSheet, new Vector2(position.X + (size.X * i), position.Y), size, velocity));
            }
        }

        public static void Draw(SpriteBatch spriteBatch)
        {
            foreach (Platform platform in platforms)
            {
                platform.Draw(spriteBatch);
            }
            
            foreach (Bird bird in birds)
            {
                bird.Draw(spriteBatch);
            }
            
            foreach (Lava lavaBlock in lavaBlocks)
            {
                lavaBlock.Draw(spriteBatch);
            }
            //s.Draw(spriteBatch, new Vector2(50, 50), new Vector2(100, 100));
        }

        public static void Update(GameTime gameTime)
        {
            GenerateLevel();

            // Remove off-screen platforms
            RemoveOffScreenObstacles(platforms);
            RemoveOffScreenObstacles(floorPlatforms);
            RemoveOffScreenObstacles(obstaclePlatforms);
            RemoveOffScreenObstacles(ballPlatforms);

            // remove off-screen birds
            RemoveOffScreenObstacles(birds);

            // remove off-screen lava
            RemoveOffScreenObstacles(lavaBlocks);

            // Updating all platforms in the scene (this is also capable of collision)
            foreach (Platform plat in platforms)
            {
                plat.Update(gameTime);
            }

            // Updating all birds
            foreach (Bird bird in birds) 
            { 
                bird.Update(gameTime);
            }

            // Updating all lavaBlocks
            foreach (Lava lavaBlock in lavaBlocks) 
            { 
                lavaBlock.Update(gameTime);
            }

            // Updating positions of the GenCheck platforms (no collision or anything like that handled)
            foreach (Platform plat in floorPlatforms)
            {
                plat.Update(gameTime);
            }
            foreach (Platform plat in obstaclePlatforms)
            {
                plat.Update(gameTime);
            }
            foreach (Platform platform in roofPlatforms)
            {
                platform.Update(gameTime);
            }
            foreach (Platform plat in ballPlatforms)
            {
                plat.Update(gameTime);
            }
        }

        private static void GenerateLevel()
        {
            // platforms Gen
            GenerateObstacles(75, new int[] {gridRows-1}, 10, 5, floorPlatforms, floorEmptyPoints, ref hasGeneratedFloorPlatforms, platformSheet);
            GenerateObstacles(100, new int[] { 0 }, 10, 5, floorPlatforms, roofEmptyPoints, ref hasGeneratedRoofPlatforms, platformSheet);
            GenerateObstacles(90, new int[] { 1, 2, 4, 5, 7 }, 3, 5, obstaclePlatforms, obstacleEmptyPoints, ref hasGeneratedObstaclePlatforms, platformSheet);

            // birds Gen
            GenerateBirds(10, new int[] {3, 6 }, 1, 5, birds, birdEmptyPoints, ref hasGeneratedBirds, birdSheet);

            // lava Gen
            GenerateLava(15, new int[] { gridRows - 1 }, 10, 5, lavaBlocks, lavaEmptyPoints, ref hasGeneratedLava, platformSheet);
        }

        // for platforms
        private static void GenerateObstacles(int obstacleSpawnChance, int[] wichRows, int howManyObstaclesPerSpawn
      , int howManyEmptyPointsPerSpawn, List<Platform> listOfObstacles, List<Vector2> listOfVectors, ref bool hasGeneratedObstaclesBool, SpriteSheet obstacleSheet)
        {

            if (!hasGeneratedObstaclesBool)
            {
                //Debug.WriteLine("ObstacleGen.............");
                int seed = random.Next(1, 100);

                if (seed < obstacleSpawnChance) // Generate platform (PlatformSpawnChance chance)
                {
                    // Generate a random index to select from the array
                    int randomIndex = random.Next(wichRows.Length);
                    int spawnRow = wichRows[randomIndex];

                    // Position the platform at the right edge of the screen
                    int spawnColumn = gridCols - 1; // Rightmost column

                    // Calculate position based on the cell
                    Vector2 position = new Vector2(spawnColumn * cellWidth, spawnRow * cellHeight);
                    Vector2 size = new Vector2(cellWidth, cellHeight);

                    // Set initial velocity for the platform
                    Vector2 velocity = new Vector2(-levelSpeed, 0);

                    // Add Platform
                    for (int i = 1; i <= howManyObstaclesPerSpawn; i++) //generate howManyPlatformsPerSpawn platforms
                    {
                        platforms.Add(new Platform(obstacleSheet, new Vector2(position.X + (size.X * i), position.Y), size, velocity));
                        listOfObstacles.Add(new Platform(obstacleSheet, new Vector2(position.X + (size.X * i), position.Y), size, velocity));
                        //continue;
                    }
                    //Debug.WriteLine("Obstacle was added.");

                    hasGeneratedObstaclesBool = true;
                }
                else
                {
                    // Generate a random index to select from the array
                    int randomIndex = random.Next(wichRows.Length);
                    int spawnRow = wichRows[randomIndex];

                    // Position the platform at the right edge of the screen
                    int spawnColumn = gridCols - 1; // Rightmost column

                    // Calculate position based on the cell
                    Vector2 position = new Vector2((spawnColumn * cellWidth), spawnRow * cellHeight);

                    // Add Platform
                    for (int i = 1; i <= howManyEmptyPointsPerSpawn; i++) //generate 3 platforms
                    {
                        listOfVectors.Add(new Vector2(position.X + (cellWidth * i), position.Y));
                    }
                    //Debug.WriteLine("Empty Obstacle was added.");

                    hasGeneratedObstaclesBool = true;
                }
            }
            else
            {
                // Check if the rightmost platform or empty point has left the spawning area
                bool rightEdgeClear = true;
                foreach (GameObject platform in listOfObstacles)
                {
                    if (platform.TopLeftPosition.X - (levelSpeed * 2) >= (gridCols - 1) * cellWidth)
                    {
                        rightEdgeClear = false;
                        break;
                    }
                }

                foreach (Vector2 point in listOfVectors)
                {
                    if (point.X - (levelSpeed * 2) >= (gridCols - 1) * cellWidth)
                    {
                        rightEdgeClear = false;
                        break;
                    }
                }

                if (rightEdgeClear)
                {
                    hasGeneratedObstaclesBool = false;
                }
            }
            for (int i = 0; i < listOfVectors.Count; i++) // we have to use a for loop instead of foreach because we can't modify a foreach variable
            {
                listOfVectors[i] -= new Vector2(levelSpeed, 0);
            }
        }

        private static void GenerateBirds(int obstacleSpawnChance, int[] wichRows, int howManyObstaclesPerSpawn,
        int howManyEmptyPointsPerSpawn, List<Bird> listOfObstacles, List<Vector2> listOfVectors, ref bool hasGeneratedObstaclesBool, SpriteSheet birdSheet)
        {
            if (!hasGeneratedObstaclesBool)
            {
                int seed = random.Next(1, 100);

                if (seed < obstacleSpawnChance)
                {
                    int randomIndex = random.Next(wichRows.Length);
                    int spawnRow = wichRows[randomIndex];
                    int spawnColumn = gridCols - 1;
                    Vector2 position = new Vector2(spawnColumn * cellWidth, spawnRow * cellHeight);
                    Vector2 size = new Vector2(cellWidth, cellHeight);
                    Vector2 velocity = new Vector2(-levelSpeed, 0);

                    for (int i = 1; i <= howManyObstaclesPerSpawn; i++)
                    {
                        listOfObstacles.Add(new Bird(birdSheet, new Vector2(position.X + (size.X * i), position.Y), size, velocity));
                    }

                    hasGeneratedObstaclesBool = true;
                }
                else
                {
                    int randomIndex = random.Next(wichRows.Length);
                    int spawnRow = wichRows[randomIndex];
                    int spawnColumn = gridCols - 1;
                    Vector2 position = new Vector2(spawnColumn * cellWidth, spawnRow * cellHeight);

                    for (int i = 1; i <= howManyEmptyPointsPerSpawn; i++)
                    {
                        listOfVectors.Add(new Vector2(position.X + (cellWidth * i), position.Y));
                    }

                    hasGeneratedObstaclesBool = true;
                }
            }
            else
            {
                bool rightEdgeClear = true;
                foreach (Bird bird in listOfObstacles)
                {
                    if (bird.TopLeftPosition.X - (levelSpeed * 2) >= (gridCols - 1) * cellWidth)
                    {
                        rightEdgeClear = false;
                        break;
                    }
                }

                foreach (Vector2 point in listOfVectors)
                {
                    if (point.X - (levelSpeed * 2) >= (gridCols - 1) * cellWidth)
                    {
                        rightEdgeClear = false;
                        break;
                    }
                }

                if (rightEdgeClear)
                {
                    hasGeneratedObstaclesBool = false;
                }
            }

            for (int i = 0; i < listOfVectors.Count; i++)
            {
                listOfVectors[i] -= new Vector2(levelSpeed, 0);
            }
        }
        private static void GenerateLava(int obstacleSpawnChance, int[] wichRows, int howManyObstaclesPerSpawn,
        int howManyEmptyPointsPerSpawn, List<Lava> listOfObstacles, List<Vector2> listOfVectors, ref bool hasGeneratedObstaclesBool, SpriteSheet birdSheet)
        {
            if (!hasGeneratedObstaclesBool)
            {
                int seed = random.Next(1, 100);

                if (seed < obstacleSpawnChance)
                {
                    int randomIndex = random.Next(wichRows.Length);
                    int spawnRow = wichRows[randomIndex];
                    int spawnColumn = gridCols - 1;
                    Vector2 position = new Vector2(spawnColumn * cellWidth, spawnRow * cellHeight);
                    Vector2 size = new Vector2(cellWidth, cellHeight);
                    Vector2 velocity = new Vector2(-levelSpeed, 0);

                    for (int i = 1; i <= howManyObstaclesPerSpawn; i++)
                    {
                        listOfObstacles.Add(new Lava(platformSheet, new Vector2(position.X + (size.X * i), position.Y), size, velocity));
                    }

                    hasGeneratedObstaclesBool = true;
                }
                else
                {
                    int randomIndex = random.Next(wichRows.Length);
                    int spawnRow = wichRows[randomIndex];
                    int spawnColumn = gridCols - 1;
                    Vector2 position = new Vector2(spawnColumn * cellWidth, spawnRow * cellHeight);

                    for (int i = 1; i <= howManyEmptyPointsPerSpawn; i++)
                    {
                        listOfVectors.Add(new Vector2(position.X + (cellWidth * i), position.Y));
                    }

                    hasGeneratedObstaclesBool = true;
                }
            }
            else
            {
                bool rightEdgeClear = true;
                foreach (Lava lavaBlocks in listOfObstacles)
                {
                    if (lavaBlocks.TopLeftPosition.X - (levelSpeed * 2) >= (gridCols - 1) * cellWidth)
                    {
                        rightEdgeClear = false;
                        break;
                    }
                }

                foreach (Vector2 point in listOfVectors)
                {
                    if (point.X - (levelSpeed * 2) >= (gridCols - 1) * cellWidth)
                    {
                        rightEdgeClear = false;
                        break;
                    }
                }

                if (rightEdgeClear)
                {
                    hasGeneratedObstaclesBool = false;
                }
            }

            for (int i = 0; i < listOfVectors.Count; i++)
            {
                listOfVectors[i] -= new Vector2(levelSpeed, 0);
            }
        }


        private static void RemoveOffScreenObstacles(List<Platform> obstacleList)
        {
            for (int i = obstacleList.Count - 1; i >= 0; i--)
            {
                if (obstacleList[i].IsOffScreen)
                {
                    obstacleList.RemoveAt(i);
                }
            }
        }
        private static void RemoveOffScreenObstacles(List<Bird> obstacleList)
        {
            for (int i = obstacleList.Count - 1; i >= 0; i--)
            {
                if (obstacleList[i].IsOffScreen)
                {
                    obstacleList.RemoveAt(i);
                }
            }
        }
        private static void RemoveOffScreenObstacles(List<Lava> obstacleList)
        {
            for (int i = obstacleList.Count - 1; i >= 0; i--)
            {
                if (obstacleList[i].IsOffScreen)
                {
                    obstacleList.RemoveAt(i);
                }
            }
        }
    }
}
