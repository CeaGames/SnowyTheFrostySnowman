﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace FrostyTheSnowman
{
    internal static class Snowman // Composing all objects/classes we need for the PlayerAvatar
    {
        // Variables
        private static Texture2D headTexture;
        private static Texture2D ballTexture;
        private static SpriteSheet headSheet;
        private static SpriteSheet ballSheet;

        private static Head headGameobject;

        public static List<Snowball> snowballs;
        private static List<Snowball> snowballsToBeRemoved;

        public static bool isActive = true;
        public static float gravity = 6f;


        private static Game1 Game;

        public static void Initialize()
        {
        }

        public static void LoadContent(Game1 game)
        {
            headTexture = GameSettings.Textures[0];
            ballTexture = GameSettings.Textures[1];
            headSheet = new SpriteSheet(headTexture, 1, 1);
            ballSheet = new SpriteSheet(ballTexture, 1, 1);
            headGameobject = new Head(headSheet, new Vector2(GameSettings.ScreenWidth / 8, GameSettings.ScreenHeight / 1.25f), new Vector2(100, 100), new Vector2(0, 0));
            snowballs = new List<Snowball>();
            snowballsToBeRemoved = new List<Snowball>();

            Game = game;
        }

        public static void Update(GameTime gameTime)
        {
            if (isActive)
            {
                headGameobject.Update(gameTime);
                SpawnBall();
                foreach (Snowball b in snowballs)
                {
                    b.Update(gameTime);
                }

                RemoveBall();
            }
        }

        public static void Draw(SpriteBatch spriteBatch)
        {
            if (isActive)
            {
                headGameobject.Draw(spriteBatch);

                foreach (Snowball b in snowballs)
                {
                    b.Draw(spriteBatch);
                    b.DrawCol(spriteBatch);
                }
                headGameobject.DrawCol(spriteBatch);
            }
        }

        private static void SpawnBall()
        {
            if (UserInput.IsLeftClick() && !headGameobject.IsCollidingUp)
            {
                Vector2 previousPosition = headGameobject.TopLeftPosition;
                headGameobject.TopLeftPosition -= new Vector2(0, headGameobject.Size.Y);

                snowballs.Add(new Snowball(ballSheet, previousPosition, headGameobject.Size, headGameobject.Velocity));
            }
        }

        private static void RemoveBall()
        {
            // Remove identified snowballs
            foreach (Snowball ball in snowballsToBeRemoved)
            {
                Level.ballPlatforms.Add(new Platform(ballSheet, ball.TopLeftPosition, ball.Size, new Vector2(-Level.levelSpeed, 0)));
                Level.platforms.Add(new Platform(ballSheet, ball.TopLeftPosition, ball.Size, new Vector2(-Level.levelSpeed, 0)));
                snowballs.Remove(ball);
            }

            // Clear the removal list after removing the balls
            snowballsToBeRemoved.Clear();
        }

        public static void AddToRemoveList(Snowball ball)
        {
            // Add ball to the removal list if it's not already there
            if (!snowballsToBeRemoved.Contains(ball))
            {
                snowballsToBeRemoved.Add(ball);
            }
        }

        public static void Die()
        {
            Game.ChangeScreen(GameSettings.screens[2]);
        }
    }
}
