﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;

namespace FrostyTheSnowman
{
    internal class GameOverScreen : Screen
    {
        public GameOverScreen(Game1 game) : base(game) { }

        public override void Initialize()
        {
            // Initialize startup screen elements
        }

        public override void LoadContent(ContentManager content)
        {
            // Load content for the startup screen
        }

        public override void Update(GameTime gameTime)
        {
            // Update logic for the startup screen
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            // Draw the startup screen
            spriteBatch.Draw(GameSettings.Textures[0], new Rectangle(GameSettings.ScreenWidth / 2 - 500, GameSettings.ScreenHeight / 2 - 500, 500, 500), Color.White);
        }
    }
}
