﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class SpriteSheet
{
    // Properties
    public Texture2D Texture { get; set; }
    public int Rows { get; set; }
    public int Columns { get; set; }
    public Vector2 TopLeftPosition { get; set; }
    public Vector2 Size { get; set; }
    public int SpriteIndex { get; set; }
    public Vector2 SpriteSize { get; set; }
    public Rectangle DestinationRectangle { get; set; }
    public float Rotation { get; set; }
    public float RotationSpeed { get; set; }

    // Constructor
    public SpriteSheet(Texture2D texture, int rows, int columns)
    {
        Texture = texture;
        Rows = rows;
        Columns = columns;
        // Initialize other properties as needed
    }

    // Methods
    public virtual void Update(GameTime gameTime)
    {

    }

    public virtual void Draw(SpriteBatch spriteBatch, Vector2 position, Vector2 size)
    {
        //dr defines the rectangle the texture will be slapped onto
        Rectangle dr = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
        //sr defines what portion of the texture you want to draw
        Rectangle sr = new Rectangle(0, 0, Texture.Width / Columns, Texture.Height / Rows);

        spriteBatch.Draw(Texture, dr, sr, Color.White);
    }
    public virtual void Draw(SpriteBatch spriteBatch, Vector2 position, Vector2 size, Color color)
    {
        //dr defines the rectangle the texture will be slapped onto
        Rectangle dr = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
        //sr defines what portion of the texture you want to draw
        Rectangle sr = new Rectangle(0, 0, Texture.Width / Columns, Texture.Height / Rows);

        spriteBatch.Draw(Texture, dr, sr, color);
    }
}

