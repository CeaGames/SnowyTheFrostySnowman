﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

public static class UserInput
{
    private static MouseState currentMouseState;
    private static MouseState previousMouseState;
    private static KeyboardState currentKeyboardState;
    private static KeyboardState previousKeyboardState;

    static UserInput()
    {
        currentMouseState = Mouse.GetState();
        currentKeyboardState = Keyboard.GetState();
    }

    public static void Update()
    {
        previousMouseState = currentMouseState;
        currentMouseState = Mouse.GetState();

        previousKeyboardState = currentKeyboardState;
        currentKeyboardState = Keyboard.GetState();
    }

    // Check if the left mouse button was clicked
    public static bool IsLeftClick()
    {
        return currentMouseState.LeftButton == ButtonState.Pressed &&
               previousMouseState.LeftButton == ButtonState.Released;
    }

    // Check if the left mouse button is being held down
    public static bool IsLeftButtonHeld()
    {
        return currentMouseState.LeftButton == ButtonState.Pressed &&
               previousMouseState.LeftButton == ButtonState.Pressed;
    }

    // Check if an arrow key is pressed
    public static bool IsKeyPressed(Keys key)
    {
        return currentKeyboardState.IsKeyDown(key) && previousKeyboardState.IsKeyUp(key);
    }

    // Check if an arrow key is being held down
    public static bool IsKeyHeld(Keys key)
    {
        return currentKeyboardState.IsKeyDown(key);
    }

    // Additional method to get mouse position
    public static Point GetMousePosition()
    {
        return currentMouseState.Position;
    }
}
