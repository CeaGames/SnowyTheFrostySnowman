﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FrostyTheSnowman
{
    internal class Snowball : global::GameObject
    {
        // Properties
        public bool IsCollidingUp { get; set; }
        public bool IsCollidingDown { get; set; }
        public bool IsCollidingSide { get; set; }


        //Variables
        private Rectangle downCollisionRectangle;
        private Rectangle sideCollisionRectangle;

        public Snowball(SpriteSheet visualization, Vector2 position, Vector2 size, Vector2 velocity)
            : base(visualization, position, size, velocity)
        {
            downCollisionRectangle = new Rectangle();
            sideCollisionRectangle = new Rectangle();
        }

        public override void Update(GameTime gameTime)
        {
            if (IsActive)
            {
                base.Update(gameTime);
                Gravity();
                Collision();
                BallCollision();
            }
        }

        private void Gravity()
        {
            if (!IsCollidingDown)
            {
                Velocity = new Vector2(Velocity.X, Snowman.gravity);
            }
            else
            {
                Velocity = new Vector2(Velocity.X, 0);
            }
        }

        public void DrawCol(SpriteBatch spriteBatch)
        {
            if (IsActive)
            {
                if (!IsCollidingSide)
                {
                    spriteBatch.Draw(GameSettings.Textures[2], downCollisionRectangle, Color.Black);

                    spriteBatch.Draw(GameSettings.Textures[2], sideCollisionRectangle, Color.Black);
                }
            }
        }

        private void BallCollision()
        {
            IsCollidingDown = false;
            foreach (Snowball snowball in Snowman.snowballs)
            {
                if (snowball != this && snowball.GetHitBoxRectangle().Intersects(downCollisionRectangle))
                {
                    IsCollidingDown = true;

                    if (IsCollidingWith(snowball))
                    {
                        Velocity = new Vector2(Velocity.X, -4); 
                        //making sure the balls aren't clipping into eachother
                    }
                    break;
                }
            }
        }

        private void Collision()
        {
            downCollisionRectangle
                = new Rectangle((int)TopLeftPosition.X + (int)Size.X / 3, (int)TopLeftPosition.Y + (int)(Size.Y)
                              , (int)Size.X / 4, (int)Size.Y / 20);

            sideCollisionRectangle
                = new Rectangle((int)TopLeftPosition.X + (int)Size.X, (int)TopLeftPosition.Y + (int)(Size.Y / 4)
                              , (int)Size.X / 10, (int)(Size.Y / 3));

            IsCollidingDown = false;
            IsCollidingSide = false;

            foreach (Lava lavaBlock in Level.lavaBlocks)
            {
                if (lavaBlock.GetHitBoxRectangle().Intersects(downCollisionRectangle) || lavaBlock.GetHitBoxRectangle().Intersects(sideCollisionRectangle))
                {
                    Snowman.AddToRemoveList(this);
                }
            }

            foreach (Bird bird in Level.birds)
            {
                if (bird.GetHitBoxRectangle().Intersects(sideCollisionRectangle))
                {

                    IsCollidingSide = true;
                    Snowman.AddToRemoveList(this);
                    break;
                }
            }

            foreach (GameObject platform in Level.platforms)
            {
                if (platform.GetHitBoxRectangle().Intersects(downCollisionRectangle))
                {
                    IsCollidingDown = true;
                    Velocity = new Vector2(Velocity.X, 0); // Stop vertical movement
                    if (IsCollidingWith(platform))
                    {
                        Velocity = new Vector2(Velocity.X, -4);
                        //making sure the balls aren't clipping into eachother
                    }
                    break;
                }
            }
            foreach (GameObject platform in Level.platforms)
            {

                if (platform.GetHitBoxRectangle().Intersects(sideCollisionRectangle))
                {
                    IsCollidingSide = true;
                    Snowman.AddToRemoveList(this);
                    break;
                }
            }
        }
    }
}
