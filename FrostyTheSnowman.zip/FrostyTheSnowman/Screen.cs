﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using FrostyTheSnowman;

public abstract class Screen
{
    protected Game1 Game;

    public Screen(Game1 game)
    {
        Game = game;
    }

    public abstract void Initialize();
    public abstract void LoadContent(ContentManager content);
    public abstract void Update(GameTime gameTime);
    public abstract void Draw(SpriteBatch spriteBatch);
}

