﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;

namespace FrostyTheSnowman
{
    internal class Head : global::GameObject
    {
        //properties
        public bool IsCollidingUp { get; set; }
        public bool IsCollidingDown { get; set; }
        public bool IsCollidingSide { get; set; }


        //variables
        private Rectangle downCollisionRectangle;
        private Rectangle sideCollisionRectangle;
        private Rectangle upCollisionRectangle;


        public Head(SpriteSheet visualization, Vector2 position, Vector2 size, Vector2 velocity) 
            : base(visualization, position, size, velocity)
        {
            downCollisionRectangle = new Rectangle();
            sideCollisionRectangle = new Rectangle();
            upCollisionRectangle = new Rectangle();
        }

        public override void Update(GameTime gameTime)
        {
            if (IsActive)
            {
                base.Update(gameTime);
                Gravity();
                Collision();
                BallCollision();
            }
        }

        private void Gravity()
        {
            if (!IsCollidingDown)
            {
                Velocity = new Vector2(Velocity.X, Snowman.gravity);
            }
            else
            {
                Velocity = new Vector2(Velocity.X, 0);
            }
        }

        public void DrawCol(SpriteBatch spriteBatch)
        {
            if (IsActive)
            {
                spriteBatch.Draw(GameSettings.Textures[2], downCollisionRectangle, Color.Black);

                spriteBatch.Draw(GameSettings.Textures[2], sideCollisionRectangle, Color.Black);

                spriteBatch.Draw(GameSettings.Textures[2], upCollisionRectangle, Color.Black);
            }
        }

        private void BallCollision()
        {
            IsCollidingDown = false;
            foreach (Snowball snowball in Snowman.snowballs)
            {
                if (snowball.GetHitBoxRectangle().Intersects(downCollisionRectangle))
                {
                    IsCollidingDown = true;

                    if (IsCollidingWith(snowball))
                    {
                        Velocity = new Vector2(Velocity.X, -Snowman.gravity);
                        //making sure the balls aren't clipping into eachother
                    }
                    break;
                }
            }
        }

        private void Collision()
        {
            downCollisionRectangle = new Rectangle(
                (int)TopLeftPosition.X + (int)Size.X / 3,
                (int)TopLeftPosition.Y + (int)Size.Y,
                (int)(Size.X / 1.75f),
                (int)Size.Y / 20
            );

            sideCollisionRectangle = new Rectangle(
                (int)TopLeftPosition.X + (int)Size.X,
                (int)TopLeftPosition.Y + (int)(Size.Y / 4),
                (int)Size.X / 10,
                (int)(Size.Y / 3)
            );

            upCollisionRectangle = new Rectangle(
                (int)TopLeftPosition.X + (int)Size.X / 3,
                (int)TopLeftPosition.Y - (int)(Size.Y - (Size.Y / 10)),
                (int)Size.X / 4,
                (int)Size.Y / 20
            );

            IsCollidingDown = false;
            IsCollidingSide = false;
            IsCollidingUp = false;
            foreach(Lava lavaBlock in Level.lavaBlocks)
            {
                if (lavaBlock.GetHitBoxRectangle().Intersects(downCollisionRectangle) || lavaBlock.GetHitBoxRectangle().Intersects(sideCollisionRectangle))
                {
                    Snowman.Die();
                }
            }

            foreach(Bird bird in Level.birds)
            {
                if (bird.GetHitBoxRectangle().Intersects(sideCollisionRectangle))
                {
                    IsCollidingSide = true;
                    Snowman.Die();
                }
            }

            foreach (GameObject platform in Level.platforms)
            {
                if (platform.GetHitBoxRectangle().Intersects(sideCollisionRectangle) || sideCollisionRectangle.Y > GameSettings.ScreenHeight)
                {
                    IsCollidingSide = true;
                    Snowman.Die();
                    break; // Stop checking other collisions since Snowman dies
                }

                if (platform.GetHitBoxRectangle().Intersects(downCollisionRectangle))
                {
                    IsCollidingDown = true;
                    Velocity = new Vector2(Velocity.X, 0); // Stop vertical movement

                    if (IsCollidingWith(platform))
                    {
                        Velocity = new Vector2(Velocity.X, -Snowman.gravity);
                        //Debug.WriteLine("is unclipping");
                    }
                }

                if (platform.GetHitBoxRectangle().Intersects(upCollisionRectangle) || upCollisionRectangle.Y < 0)
                {
                    IsCollidingUp = true;
                    //Debug.WriteLine("beeep.....................;;");
                }
            }
        }

    }
}
