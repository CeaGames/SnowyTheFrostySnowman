﻿using Microsoft.Xna.Framework;

namespace FrostyTheSnowman
{
    internal class Platform : GameObject
    {
        public Platform(SpriteSheet visualization, Vector2 position, Vector2 size, Vector2 velocity)
            : base(visualization, position, size, velocity)
        {
        }
    }
}
