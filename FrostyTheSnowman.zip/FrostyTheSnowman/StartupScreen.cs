﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace FrostyTheSnowman
{
    internal class StartupScreen : Screen
    {
        public StartupScreen(Game1 game) : base(game) { }

        public override void Initialize()
        {
            // Initialize startup screen elements
        }

        public override void LoadContent(ContentManager content)
        {
            // Load content for the startup screen
        }

        public override void Update(GameTime gameTime)
        {
            // Update logic for the startup screen
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            // Draw the startup screen
        }
    }
}