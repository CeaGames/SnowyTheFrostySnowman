﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class TextControl : ControlBase
{
    // Properties
    public string Text { get; set; }
    public SpriteFont Font { get; set; }
    public Color TextColor { get; set; }

    // Methods
    public override void Update()
    {
        // Handle input states
    }

    public override void Draw(SpriteBatch spriteBatch)
    {
        // Draw logic to center text
    }
}
