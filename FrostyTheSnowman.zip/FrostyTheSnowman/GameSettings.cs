﻿using FrostyTheSnowman;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using SharpDX.Direct3D9;
using System.Collections.Generic;

public static partial class GameSettings
{
    // Basic properties
    public static int ScreenWidth { get; set; } = 1600;
    public static int ScreenHeight { get; set; } = 1000;
    public static Screen ActiveScreen { get; set; }



    // Additional properties
    public static List<Texture2D> Textures { get; set; } = new List<Texture2D>();
    public static List<SpriteFont> Fonts { get; set; } = new List<SpriteFont>();

    public static List<Screen> screens = new List<Screen>();

}
