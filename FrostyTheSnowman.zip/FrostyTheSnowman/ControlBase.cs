﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public abstract class ControlBase
{
    // Properties
    public Vector2 Position { get; set; }
    public Vector2 Size { get; set; }
    public Color BackgroundColor { get; set; }
    public Color StrokeColor { get; set; }

    // Methods
    public abstract void Update();
    public abstract void Draw(SpriteBatch spriteBatch);
}
