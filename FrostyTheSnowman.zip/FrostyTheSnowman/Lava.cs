﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace FrostyTheSnowman
{
    internal class Lava : GameObject
    {
        public Lava(SpriteSheet visualization, Vector2 position, Vector2 size, Vector2 velocity)
    : base(visualization, position, size, velocity)
        {
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            if (!IsActive)
                return;

            Visualization.Draw(spriteBatch, TopLeftPosition, Size, Color.Orange);
        }
    }
}
