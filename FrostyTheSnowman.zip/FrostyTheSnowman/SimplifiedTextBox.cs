﻿public class SimplifiedTextBox : TextControl
{
    // Methods
    public override void Update()
    {
        // Logic for text editing on user input
    }
}
