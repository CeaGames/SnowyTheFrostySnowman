﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace FrostyTheSnowman
{
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = GameSettings.ScreenWidth;
            graphics.PreferredBackBufferHeight = GameSettings.ScreenHeight;
            Content.RootDirectory = "Content";
            IsFixedTimeStep = true;
            TargetElapsedTime = TimeSpan.FromSeconds(1.0f / 60.0f); //60 fps
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            GameSettings.screens.Add(new StartupScreen(this));
            GameSettings.screens.Add(new PlayScreen(this));
            GameSettings.screens.Add(new GameOverScreen(this));
            GameSettings.ActiveScreen = GameSettings.screens[1];
            GameSettings.ActiveScreen.Initialize();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            //Loading Textures
            GameSettings.Textures.Add(Content.Load<Texture2D>("SnowManHead"));
            GameSettings.Textures.Add(Content.Load<Texture2D>("snowball"));
            GameSettings.Textures.Add(Content.Load<Texture2D>("Platform"));
            GameSettings.Textures.Add(Content.Load<Texture2D>("SpriteSheetBirdEnemy"));
            //GameSettings.Textures.Add(Content.Load<Texture2D>("Platform"));

            //Loading ...

            //Loading Rest
            spriteBatch = new SpriteBatch(GraphicsDevice);
            GameSettings.ActiveScreen.LoadContent(Content);
        }

        protected override void Update(GameTime gameTime)
        {
            UserInput.Update();
            GameSettings.ActiveScreen.Update(gameTime);
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();

            GraphicsDevice.Clear(Color.CornflowerBlue);

            GameSettings.ActiveScreen.Draw(spriteBatch);

            spriteBatch.End();
            base.Draw(gameTime);
        }

        public void ChangeScreen(Screen newScreen)
        {
            //you can call this function in another screen class to change to a new screen (ex: ChangeScreen(new ScreenIWant);
            
            GameSettings.ActiveScreen = newScreen;
            GameSettings.ActiveScreen.Initialize();
            GameSettings.ActiveScreen.LoadContent(Content);
        }
    }

}
